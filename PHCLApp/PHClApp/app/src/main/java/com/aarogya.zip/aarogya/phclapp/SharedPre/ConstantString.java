package com.aarogya.phclapp.SharedPre;



public class ConstantString {
    public static String URL = "http://phclproject.tech/apis/"; //17054365 9981547651 17091233 9755400568
//    public static String URL = "https://enriquezfuneralparlor.com/apis/"; //17054365 9981547651 17091233 9755400568
}