package com.aarogya.phclapp.Activity;

import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;

import com.aarogya.phclapp.Adapter.LawModel;
import com.aarogya.phclapp.R;

public class SingleCategoryDetails extends AppCompatActivity {
    LawModel lawModel;
    TextView mTitleTv, mDescTv, buttonfav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_singlecategory_details);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        setTitle("Law Detail");
        mTitleTv = findViewById(R.id.cat);
        mDescTv = findViewById(R.id.cat_det);
        lawModel = (LawModel) getIntent().getSerializableExtra("lawmodel");
        mTitleTv.setText(lawModel.getTitle());
        mDescTv.setText(lawModel.getDesc());
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
