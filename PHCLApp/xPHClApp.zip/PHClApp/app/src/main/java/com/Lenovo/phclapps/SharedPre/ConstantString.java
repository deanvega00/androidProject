package com.Lenovo.phclapps.SharedPre;



public class ConstantString {

    public static String URL = "https://phclproject.tech/apis/"; //17054365 9981547651 17091233 9755400568
//    public static String URL = "http://192.168.1.106/apis/"; //17054365 9981547651 17091233 9755400568

}