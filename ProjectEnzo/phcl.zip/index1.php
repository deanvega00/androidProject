<?php 
session_start();
include ("./Page/database/connect.php");
include ('./include/page-header.php');
if (!isset($_SESSION["id"])){header("location: ./page-login.php");}

?>

    <div id="right-panel" class="right-panel">
        <div class="breadcrumbs">
            <div class="col-sm-4">
                
            </div>
          
        </div>

        <div class="content mt-12">
		</div>
	</div>

</div
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
	.box{border: 0px solid red; height: 600px; width: 100%;}





	</style>
</head>
<body>
<br><br><br>
<img src="images/logo2.png" height="200px" width="200px"><br>
<h1>Tarlac Sate University College of Law and Criminal Justice</h1>

	<div class="box">
<h2>Goal</h2>
<p style="text-align:justify; margin-right: 40px;">The field of criminology is a study of crime and the various agencies of justice as they operate and react to crime, criminals and the victims. it is therefore the mission of the College of Criminal Justice Education – Criminology program to provide the community with professionally competent and morally upright graduates who can deliver efficient and effective services in crime prevention, crime detection and investigation, law enforcement, and the custody and the rehabilitation of offenders. The College of Criminal Justice Education – Criminology Department is envisioned to be actively and continually involved in producing graduates who have the knowledge and skills in addressing the problem of criminality in the country and the competence to meet the challenge of globalization in the field of criminology. (Extracted from CMO 21 s.2005) 
	
</p>
	</div>


</body>
</html>

   