<?php

$servername = "localhost";
$username = "i2836162_wp11";
$password = "L.UX9MGFjOme6PSIYWH92";
$dbname = "i2836162_wp11";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

?>